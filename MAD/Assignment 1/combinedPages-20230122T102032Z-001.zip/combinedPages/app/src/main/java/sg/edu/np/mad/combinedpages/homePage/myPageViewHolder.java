package sg.edu.np.mad.combinedpages.homePage;

import android.media.Image;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import sg.edu.np.mad.combinedpages.R;

public class myPageViewHolder extends RecyclerView.ViewHolder {

    TextView rName;
    CardView cardView;
    ImageView image;

    public myPageViewHolder(View itemView) {
        super(itemView);
        rName = itemView.findViewById(R.id.recipes_name);
        cardView = itemView.findViewById(R.id.cardview_id);
        image = itemView.findViewById(R.id.imageView2);
    }
}
