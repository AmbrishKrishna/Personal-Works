package sg.edu.np.mad.combinedpages.profilePage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import sg.edu.np.mad.combinedpages.R;

public class EditUser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user);

        // -------------------------------------ASG 2-----------------------------------------------------
        // ACCESS USER DATABASE
        // UPDATE USER INFORMATION FOR NEW CHANGE
        //------------------------------------------------------------------------------------------------

        // Receive intent
        Intent intent = getIntent();

        // Reuse bundle
        Bundle b = intent.getExtras();

        // Find EditTexts
        EditText newName = findViewById(R.id.newName);
        EditText newUsername = findViewById(R.id.newUsername);
        EditText newEmail = findViewById(R.id.newEmail);
        EditText newDOB = findViewById(R.id.newDOB);
        EditText oldPassword = findViewById(R.id.oldPassword);
        EditText newPassword = findViewById(R.id.newPassword);
        EditText newPassword2 = findViewById(R.id.newPassword2);

        // Create new string objects with new information
        String name = String.valueOf(newName);
        String username = String.valueOf(newUsername);
        String email = String.valueOf(newEmail);
        String dob = String.valueOf(newDOB);
        String password = "";

        // Checks for password
        // Checks if any passwords are blank
        if (oldPassword.equals("") || newPassword.equals("") || newPassword2.equals("")) {
            Toast.makeText(EditUser.this, "No password detected. Please try again.",
                    Toast.LENGTH_SHORT).show();
        }
        else {
            // Checks if password and confirm-password are the same
            if (String.valueOf(newPassword) == String.valueOf(newPassword2)) {
                // Checks if new password is different from old password
                if (String.valueOf(oldPassword) != String.valueOf(newPassword)) {
                    password = String.valueOf(newPassword);
                }
                else {
                    Toast.makeText(EditUser.this, "New password must be different from old password. Please try again.",
                            Toast.LENGTH_SHORT).show();
                }
            }
            else {
                Toast.makeText(EditUser.this, "New password does not match. Please try again",
                        Toast.LENGTH_SHORT).show();
            }
        }

        // Add new information to a bundle and send back to homePage
        b.putString("class", "EditUser");
        b.putString("newName", name);
        b.putString("newPassword", password);
        b.putString("newDOB", dob);
        b.putString("newEmail", email);
        b.putString("newUsername", username);
        intent.putExtras(b);

        // Finds button
        Button button = findViewById(R.id.applyChanges);
        Button cancel = findViewById(R.id.cancel);

        // create onClickListeners
        // Apply changes
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(EditUser.this, profilePage.class);
                i.putExtras(b);
                startActivity(i);
            }
        });

        // Cancel
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}