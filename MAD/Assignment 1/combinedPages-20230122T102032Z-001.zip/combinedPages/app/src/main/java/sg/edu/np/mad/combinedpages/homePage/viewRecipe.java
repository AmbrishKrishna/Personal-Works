package sg.edu.np.mad.combinedpages.homePage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import sg.edu.np.mad.combinedpages.R;

public class viewRecipe extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_recipe);

        // Receives any intents
        Intent intent = getIntent();

        // Making all the variables
        TextView mName = findViewById(R.id.name_recipe);
        TextView mDescription = findViewById(R.id.description_recipe);
        TextView mDuration = findViewById(R.id.duration_recipe);
        TextView mIngredients = findViewById(R.id.ingredients_recipe);
        TextView mMethod = findViewById(R.id.method_recipe);
        ImageView mImage = findViewById(R.id.imageView);

        //To get respective values for each recipe
        String Name = intent.getStringExtra("Recipe Name");
        String Description = intent.getStringExtra("Recipe Description");
        int Duration = intent.getIntExtra("Recipe Duration", 0);
        String Ingredients = intent.getStringExtra("Recipe Ingredients");
        String Method = intent.getStringExtra("Recipe Method");
        int Image = intent.getIntExtra("image", 0);

        //To set respective values for each recipe
        mName.setText(Name);
        mDescription.setText(Description);
        mDuration.setText(Duration + " minutes");
        mIngredients.setText(Ingredients);
        mMethod.setText(Method);
        mImage.setImageResource(Image);
    }
}