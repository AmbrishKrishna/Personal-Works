package sg.edu.np.mad.combinedpages.LogInPage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import sg.edu.np.mad.combinedpages.R;

public class ForgotPassword_otp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password_otp);

        // Receives any intents
        Intent intent = getIntent();

        // Code that sends OTP to email
        // NOT SURE HOW TO CHECK OTP
        // ADD SOME CODE TO CHECK USER INPUT (IE CORRECT DATA TYPE, INVALID CREDENTIALS)

        // Find EditText
        EditText OTP = findViewById(R.id.OTP);

        // Create otp
        String otp = String.valueOf(OTP);

        // Finds buttons
        Button NextButton2 = findViewById(R.id.nextbutton2);

        // Creates onClickListener for buttons
        NextButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(ForgotPassword_otp.this, NewPassword.class);
                startActivity(myIntent);
            }
        });
    }
}