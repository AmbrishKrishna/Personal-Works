package sg.edu.np.mad.combinedpages.homePage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

import sg.edu.np.mad.combinedpages.R;
import sg.edu.np.mad.combinedpages.Recipe;
import sg.edu.np.mad.combinedpages.createPage.createPage;
import sg.edu.np.mad.combinedpages.profilePage.profilePage;
import sg.edu.np.mad.combinedpages.searchPage.searchPage;

public class homePage extends AppCompatActivity {

    List<Recipe> recipeList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        // -------------------------------------ASG 2-----------------------------------------------------
        // ACCESS RECIPES FROM DATABASE
        //------------------------------------------------------------------------------------------------

        // Receives any intent
        Intent intent = getIntent();

        // Reuse bundle
        Bundle b = intent.getExtras();

        // Create a List to store all the recipes
        recipeList = new ArrayList<Recipe>();

        // Create temporary recipes
        CreateExampleRecipes(recipeList);

        // Checks if user just came from createPage
        if (b.getString("class") == "Create") {
            String rName = intent.getStringExtra("RecipeName");
            int rDuration = intent.getIntExtra("RecipeDuration", 0);
            String rIngredient = intent.getStringExtra("RecipeIngredient");
            String rDescription = intent.getStringExtra("RecipeDescription");
            String rSteps = intent.getStringExtra("RecipeSteps");
            Recipe temp = new Recipe(rName, rDuration, rIngredient, rDescription, rSteps, R.drawable.ic_launcher_foreground);
            recipeList.add(temp);
        }

        // Navigation bar (TO BE REPLACED WITH A PROPER NAVIGATION BAR)
        // Finds icons
        ImageView create = findViewById(R.id.createImage);
        ImageView profile = findViewById(R.id.profileImage);
        ImageView search = findViewById(R.id.searchImage);
        ImageView home = findViewById(R.id.homeImage);

        // Create onClickListeners for each icon
        // create
        GoToPage(create, homePage.this, createPage.class, b);

        // profile
        GoToPage(profile, homePage.this, profilePage.class, b);

        // search
        GoToPage(search, homePage.this, searchPage.class, b);

        // home
        GoToPage(home, homePage.this, homePage.class, b);

        // Creates recyclerView to display recipes
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        myPageAdapter adapter = new myPageAdapter(this, recipeList);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));
        recyclerView.setAdapter(adapter);
    }

    // Method for OnClickListeners
    public void GoToPage(ImageView i, Context c1, Class c2, Bundle b) {
        i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(c1, c2);
                i.putExtras(b);
                startActivity(i);
            }
        });
    }

    public void CreateExampleRecipes(List<Recipe> rList) {
        rList.add(new Recipe("Fried Chicken", 25, "6 Chicken thighs\n" + "6 Chicken Drumsticks\n" +
                "3 cups Flour\n" + "1 Quarter Vegetable Oil\n" + "2 tablespoons Salt\n" +
                "1 tablespoon Pepper\n" + "2 Eggs",
                "A dish consisting of chicken pieces that have been coated with seasoned flour, then pan fried to give it a crispy, juicy and delicious taste.",
                "1. In a large shallow dish, combine 2-2/3 cups flour, and teaspoons pepper. In another shallow dish, beat eggs and 1-1/2 cups water; add 1 teaspoon salt and the remaining 1-1/3 cups flour and 1/2 teaspoon pepper. Dip chicken in egg mixture, then place in flour mixture, a few pieces at a time. Turn to coat.\n"+ "\n"+
                        "2. In a deep-fat fryer, heat oil to 375°. Fry chicken, several pieces at a time, until skin is golden brown and a thermometer inserted into chicken reads 165°, 7-8 minutes on each side. Drain on paper towels.",
                R.drawable.fried_chicken
                )
        );

        //Second recipe
        rList.add(new Recipe("Chicken Rice", 25, "1 Whole Chicken\n" + "1/4 cup Kosher salt\n" +
                "6 cloves Garlic\n" + "1 tablespoon Sesame oil\n" + "2 tablspoon Cooking oil\n" +
                "1 Shallot\n" + "2 cups long-grain uncooked rice",
                " Chicken rice is a dish of poached chicken and seasoned rice, served with chilli sauce and usually with cucumber garnishes.",
                "1. Boil a large pot of water. In the meantime, clean the chicken by exfoliating with kosher or coarse salt. Rinse chicken well, inside and outside.\n" + "\n" +
                        "2. PRE-BOIL CHICKEN: When water is at a hard boil, add the chicken. Return to hard boil, let scum come to the surface. Boil for 5 minutes. Discard all the water, including the scum.\n"+ "\n" +
                        "3. Refill pot with clean water to cover the chicken by 1-inch, and add in the garlic. Bring the pot to a boil over high heat, then immediately turn the heat to low to keep a simmer. Cook for about 30 minutes more (less if you're using a smaller chicken). Check for doneness by sticking a chopstick into the flesh under the leg and see if the juices run clear or insert a thermometer into the thickest part of the thigh not touching bone. It should read 160F. The chicken will continue to cook to 165F during rest.\n"+ "\n" +
                        "4. When the chicken is cooked through, turn off the heat and remove the pot from the burner. Immediately lift and transfer the chicken into a bath of ice water to cool. The quick cooling will stop the cooking process, keeping the meat soft and tender, and giving the skin a lovely firm texture. After cooling, pat the chicken dry with paper towels and rub the sesame oil all over the chicken. This will help prevent the chicken from drying out.",
                R.drawable.chicken_rice
                )
        );

        //Third recipe
        rList.add(new Recipe("Laksa", 30,"3 tablespoons cooking oil\n" + "1/2 pack (120 g) Malaysian instant curry paste\n" +
                "2 cups (1 can) chicken broth\n" + "2 cups water\n" + "2 stalks lemongrass, white part only, pounded\n" +
                "10 tofu puffs, cut into pieces\n" + "1/2 cup evaporated milk\n" +
                "1/2 cup coconut milk\n" + "salt to taste\n" + "yellow noodles\n" +
                "bean sprouts\n" + "10 shrimp, peeled, deveined and cooked\n" +
                "3 hard-boiled eggs, cut into halves\n" + "fish cakes, cut into pieces",
                "Spicy street food noodle dish popular in Malaysia and Singapore.",
                "1.In a stockpot, add the oil and sauté the instant curry paste until aromatic. Add the chicken broth, water, lemongrass, tofu puffs and bring the soup to a boil. Lower the heat to simmer. Add the coconut milk and evaporated milk. Add salt to taste. Keep the stock on simmer.\n"+ "\n" +
                        "2.Rinse the yellow noodles and bean sprouts separately, drained and set aside.\n"+ "\n" +
                        "3.To assemble a bowl of laksa for serving, bring to boil some yellow noodles and a handful of bean sprouts. Drain the noodles and bean sprouts and transfer to a serving bowl. Top the noodles with 2-3 shrimp, a few pieces of fish cake, and some eggs. Using a ladle, pour the soup and a few pieces of tofu puffs on top of the noodles. Serve immediately.",
                R.drawable.laksa
                )
        );

        //Fourth recipe
        rList.add(new Recipe("Bee Hoon", 40,"3 tbsp oil\n" + "2 eggs\n" + "200 g rice vermicelli\n" +
                "1 tbsp chopped garlic\n" + "1 medium size onion\n" + "80 g chicken breast meat, cut into julienne\n" +
                "50 g medium size shrimps, deveined, wash with salt and drained\n" +
                "1 tablespoons dry shrimps, soak for 30 minutes and drained\n" + "40 g cabbage, cut into julienne\n" +
                "20 g carrot, cut into julienne\n" + "50 g bean sprout\n" + "10 g chopped scallions\n" +
                "3 tbsp tomato ketchup\n" + "1 tbsp chili sauce\n" + "2 tbsp oyster sauce\n" +
                "1 tbsp light soy sauce\n" + "1 tbsp dark soy sauce\n" + "1/4 tsp sesame oil\n" +
                "1/8 tsp ground white pepper",
                "Bee Hoon is the name given to the fried rice vermicelli cooked by the Singaporean. This recipe follows closely how the local hawkers prepared the noodles in Singapore, which is different from the overseas version that includes curry powder in the recipe.",
                "1.Bring a pot of water to boil. Blanch the rice vermicelli until soft, which will take about one minute.\n" + "\n" +
                        "2.Remove the vermicelli, place it in a pot of cold water. Let it cools down to room temperature. Drain away the water with a wire mesh strainer or colander. Set aside.\n" + "\n" +
                        "3.Deveined the shrimps, marinate with a half teaspoon of salt for five minutes, wash in running water until the water runs clear.\n" + "\n" +
                        "4.Soak the dry shrimps in hot water for 30 minutes. Drained.\n" + "\n" +
                        "5.Cut cabbage and carrot into julienne\n" + "\n" +
                        "6.Cut the chicken breast meat into thin slices. Mix with a half teaspoon of cornflour, 1 teaspoon of light soy sauce and one teaspoon of vegetable oil. Marinate for ten minutes.\n" + "\n" +
                        "7.Heat up 2 tablespoons of vegetable oil in the wok. Saute the chopped onions and garlic.\n" + "\n" +
                        "8.Add the breast meat, dry shrimps, shrimps and stir-fry until they are cooked.\n" + "\n" +
                        "9.Add the cabbage and carrot and stir-fry for another minute. Push all the ingredients to the side of the wok.\n" + "\n" +
                        "10.Add 1 tablespoon of vegetable oil and scramble two beaten eggs until nearly cooked. Push back the ingredients to the bottom of the wok and mix with the eggs.\n" + "\n" +
                        "11.Add the vermicelli, 2/3 of the bean sprouts and the seasonings (ingredients D). Mix well with the vermicelli.  Turn to high heat and stir-fry until aromatic.\n" + "\n" +
                        "12.Turn off the heat. Add the remaining bean sprouts and mix well.\n" + "\n" +
                        "13.Top with chopped scallion and serve.",
                R.drawable.bee_hoon
                )
        );

        //Fifth recipe
        rList.add(new Recipe("Nasi Lemak", 60,"coconut milk steamed rice\n" + "2 cups rice\n" +
                "3 screwpine leaves, tie them into a knot as shown above\n" + "salt to taste\n" +
                "1 can coconut milk (5.6 oz. / /150 ml-180 ml)\n" + "water\n" + "1 cup water\n" +
                "tamarind pulp, size of a small ping pong ball\n" + "1/2 red onion\n" +
                "1 cup ikan bilis, dried anchovies\n" + "1 clove garlic\n" + "4 shallots\n" +
                "10 dried chillies\n" + "1 teaspoon belacan, prawn paste\n" + "1/4 teaspoon salt\n" +
                "1 tablespoon sugar\n" + "2 hard boiled eggs, cut into half\n" + "3 small fish, sardines or smelt fish\n" +
                "1 small cucumber, cut into slices and then quartered",
                "Malaysian coconut milk rice, served with sambal, fried crispy anchovies, toasted peanuts and cucumber.",
                "1.Just like making steamed rice, rinse your rice and drain. Add the coconut milk, a pinch of salt, and some water. Add the pandan leaves into the rice and cook your rice.\n" + "\n" +
                        "2.Rinse the dried anchovies and drain the water. Fry the anchovies until they turn light brown and put aside.\n" + "\n" +
                        "3.Pound the prawn paste together with shallots, garlic, and deseeded dried chilies with a mortar and pestle. You can also grind them with a food processor. Slice the red onion into rings. Soak the tamarind pulp in water for 15 minutes. Squeeze the tamarind constantly to extract the flavor into the water. Drain the pulp and save the tamarind juice.\n" + "\n" +
                        "4.Heat some oil in a pan and fry the spice paste until fragrant. Add in the onion rings. Add in the ikan bilis and stir well. Add tamarind juice, salt, and sugar. Simmer on low heat until the gravy thickens. Set aside.\n" + "\n" +
                        "5.Clean the small fish, cut them into half and season with salt. Deep fry. Cut the cucumber into slices and then quartered into four small pieces. Dish up the steamed coconut milk rice and pour some sambal ikan bilis on top of the rice. Serve with fried fish, cucumber slices, and hard-boiled eggs.\n",
                R.drawable.nasi_lemak
                )
        );
    }
}