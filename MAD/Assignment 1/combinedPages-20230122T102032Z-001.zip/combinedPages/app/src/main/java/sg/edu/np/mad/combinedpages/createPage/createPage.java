package sg.edu.np.mad.combinedpages.createPage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import sg.edu.np.mad.combinedpages.R;
import sg.edu.np.mad.combinedpages.homePage.homePage;

public class createPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_recipe);

        // -------------------------------------ASG 2-----------------------------------------------------
        // UPLOAD NEW RECIPE TO DATABASE
        //------------------------------------------------------------------------------------------------

        // Receive intent
        Intent intent = getIntent();

        // Reuse bundle
        Bundle b = intent.getExtras();

        // Create EditText objects from the layout
        EditText etRecipeName = findViewById(R.id.recipeName);
        EditText etDuration = findViewById(R.id.duration);
        EditText etIngredient = findViewById(R.id.ingredients);
        EditText etDesc = findViewById(R.id.description);
        EditText etSteps = findViewById(R.id.steps);

        // onClickListener for createRecipe button
        Button createButton = findViewById(R.id.createButton);
        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Checks if there are empty fields
                if (isEmpty(etRecipeName, etDuration, etIngredient, etDesc, etSteps) == false) {
                    Toast.makeText(createPage.this, "There are empty fields. Please fill up all fields",
                            Toast.LENGTH_SHORT).show();
                }
                // Checks if fields are entered correctly
                else {
                    if (correctType(etRecipeName, etDuration, etIngredient, etDesc, etSteps) == true) {
                        Toast.makeText(createPage.this, "Recipe Created", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(createPage.this, homePage.class);
                        b.putString("RecipeName", etRecipeName.getText().toString());
                        b.putInt("RecipeDuration", Integer.valueOf(etDuration.getText().toString()));
                        b.putString("RecipeIngredient", etDuration.getText().toString().replace(",", "\n"));
                        b.putString("RecipeDescription", etDuration.getText().toString());
                        b.putString("RecipeSteps", etDuration.getText().toString().replace(",", "\n"));
                        b.putString("class", "Create");
                        i.putExtras(b);
                        startActivity(i);
                        finish();
                    }
                    else { Toast.makeText(createPage.this,
                            "Some fields are entered wrongly. Please try again", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // onClickListener for Cancel button
        Button cancelButton = findViewById(R.id.cancelButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    // Function that checks for empty EditTexts
    public boolean isEmpty(EditText name, EditText duration, EditText ingredients, EditText description, EditText steps) {
        String nameTemp = name.getText().toString();
        String durationTemp = duration.getText().toString();
        String ingredientsTemp = ingredients.getText().toString();
        String descriptionTemp = description.getText().toString();
        String stepsTemp = steps.getText().toString();

        if (nameTemp.matches("") || durationTemp.matches("") || ingredientsTemp.matches("")
                || descriptionTemp.matches("") || stepsTemp.matches("")) {
            return false;
        }
        else { return true; }
    }

    // Function that checks if fields are the proper data type
    public boolean correctType(EditText name, EditText duration, EditText ingredients, EditText description, EditText steps) {
        boolean checkDuration = TextUtils.isDigitsOnly(duration.getText());
        boolean checkName = TextUtils.isDigitsOnly(name.getText());
        boolean checkingredients = TextUtils.isDigitsOnly(ingredients.getText());
        boolean checkdescription = TextUtils.isDigitsOnly(description.getText());
        boolean checksteps = TextUtils.isDigitsOnly(steps.getText());

        if (checkDuration == true && checkName == false && checkingredients == false
                && checkdescription == false && checksteps == false) {
            return true;
        }
        else { return false; }
    }
}