package sg.edu.np.mad.combinedpages.profilePage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import sg.edu.np.mad.combinedpages.R;
import sg.edu.np.mad.combinedpages.createPage.createPage;
import sg.edu.np.mad.combinedpages.homePage.homePage;
import sg.edu.np.mad.combinedpages.searchPage.searchPage;

public class profilePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);

        // -------------------------------------ASG 2-----------------------------------------------------
        // ACCESS USER DATABASE
        // CHECK IF LOGIN INFORMATION EQUALS PROFILE INFORMATION
        //------------------------------------------------------------------------------------------------

        // Receive intent
        Intent intent = getIntent();

        // Reuse bundle
        Bundle b = intent.getExtras();

        // Find TextViews
        TextView name = findViewById(R.id.name);
        TextView username = findViewById(R.id.username);
        TextView email = findViewById(R.id.email);
        TextView dob = findViewById(R.id.dob);
        TextView password = findViewById(R.id.password);

        // Populate TextViews with user information (RETRIEVE INFO FROM LOGIN)
        if (b.getString("class") == "Login") {
            name.setText(String.valueOf(b.getString("Name")));
            username.setText(String.valueOf(b.getString("Username")));
            email.setText(String.valueOf(b.getString("Email")));
            dob.setText(String.valueOf(b.getString("DOB")));

            // Show password as *
            String temp = b.getString("Password");
            String temp2 = "";
            for (int x = 0; x < temp.length();) {
                temp2 = temp2 + "*";
                x+=1;
            }
            password.setText(temp2);
        }

        // Populate TextViews with user information (RETRIEVE INFO FROM EDITUSER)
        else if (b.getString("class") == "EditUser") {
            name.setText(String.valueOf(b.getString("newName")));
            username.setText(String.valueOf(b.getString("newUsername")));
            email.setText(String.valueOf(b.getString("newEmail")));
            dob.setText(String.valueOf(b.getString("newDOB")));

            // Show password as *
            String temp = b.getString("newPassword");
            String temp2 = "";
            for (int x = 0; x < temp.length();) {
                temp2 = temp2 + "*";
                x+=1;
            }
            password.setText(temp2);
        }

        // Find Button
        Button button = findViewById(R.id.editButton);

        // Create onClickListener
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(profilePage.this, EditUser.class);
                startActivity(i);
            }
        });

        // Navigation bar (TO BE REPLACED WITH PROPER NAVIGATION BAR)
        // Finds icons
        ImageView create = findViewById(R.id.createImage);
        ImageView profile = findViewById(R.id.profileImage);
        ImageView search = findViewById(R.id.searchImage);
        ImageView home = findViewById(R.id.homeImage);

        // Create onClickListeners for each icon
        // create
        GoToPage(create, profilePage.this, createPage.class, b);

        // profile
        GoToPage(profile, profilePage.this, profilePage.class, b);

        // search
        GoToPage(search, profilePage.this, searchPage.class, b);

        // home
        GoToPage(home, profilePage.this, homePage.class, b);
    }

    // Method for OnClickListeners
    public void GoToPage(ImageView i, Context c1, Class c2, Bundle b) {
        i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(c1, c2);
                i.putExtras(b);
                startActivity(i);
            }
        });
    }
}