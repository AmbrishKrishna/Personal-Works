package sg.edu.np.mad.combinedpages;

import android.os.Parcel;
import android.os.Parcelable;

public class Recipe {

    private String name;
    private String description;
    private String ingredients;
    private int duration;
    private String steps;
    private int thumbnail;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    public String getIngredients() {
        return ingredients;
    }
    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public int getDuration() {
        return duration;
    }
    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getSteps() { return steps; }
    public void setSteps(String steps) { this.steps = steps; }

    public int getThumbnail() { return thumbnail; }
    public void setThumbnail(int thumbnail) { this.thumbnail = thumbnail; }

    public Recipe() {}

    public Recipe(String name, int duration, String ingredients, String description, String steps, int thumbnail) {
        this.name = name;
        this.description = description;
        this.ingredients = ingredients;
        this.duration = duration;
        this.steps = steps;
        this.thumbnail = thumbnail;
    }
}