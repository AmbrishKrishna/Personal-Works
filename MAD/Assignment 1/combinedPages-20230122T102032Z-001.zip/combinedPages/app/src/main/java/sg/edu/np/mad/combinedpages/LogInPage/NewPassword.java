package sg.edu.np.mad.combinedpages.LogInPage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import sg.edu.np.mad.combinedpages.R;

public class NewPassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_password);

        // Receives any intents
        Intent intent = getIntent();

        // Finds buttons
        Button NextButton3 = findViewById(R.id.nextbutton3);

        // Create onClickListener for buttons
        NextButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Creates EditText objects
                EditText PW = findViewById(R.id.PW);
                EditText confirmPW = findViewById(R.id.confirmPW);

                // Creates password objects
                String stringPW = String.valueOf(PW);
                String stringcfmPW = String.valueOf(confirmPW);

                // Checks if both passwords are the same
                if (stringPW.equals(stringcfmPW)){

                    // UPDATE PASSWORD FOR USER BEFORE GOING OFF

                    Intent myIntent = new Intent(NewPassword.this, MainActivity.class);
                    startActivity(myIntent);
                }
                else {
                    Toast.makeText(NewPassword.this, "Passwords do not match!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}