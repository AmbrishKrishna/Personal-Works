package sg.edu.np.mad.combinedpages.homePage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import sg.edu.np.mad.combinedpages.R;
import sg.edu.np.mad.combinedpages.Recipe;

public class myPageAdapter extends RecyclerView.Adapter<myPageViewHolder> {

    List<Recipe> data;
    Context context;

    public myPageAdapter(Context context, List<Recipe> input) {
        this.context = context;
        data = input;
    }

    public myPageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(context).inflate(R.layout.recipe_cardview, parent, false);
        return new myPageViewHolder(item);
    }

    public void onBindViewHolder(myPageViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.rName.setText(data.get(position).getName());
        holder.image.setImageResource(data.get(position).getThumbnail());
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, viewRecipe.class);
                intent.putExtra("Recipe Name", data.get(position).getName());
                intent.putExtra("Recipe Description", data.get(position).getDescription());
                intent.putExtra("Recipe Duration", data.get(position).getDuration());
                intent.putExtra("Recipe Ingredients", data.get(position).getIngredients());
                intent.putExtra("Recipe Method", data.get(position).getSteps());
                intent.putExtra("image", data.get(position).getThumbnail());
                context.startActivity(intent);
            }
        });
    }

    public int getItemCount() { return data.size(); }
}