package sg.edu.np.mad.combinedpages.LogInPage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.util.BuddhistCalendar;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import sg.edu.np.mad.combinedpages.R;
import sg.edu.np.mad.combinedpages.User;
import sg.edu.np.mad.combinedpages.homePage.homePage;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // -------------------------------------ASG 2-----------------------------------------------------
        // MAKE DATABASE FOR USERS. WHILE YOU'RE FIGURING THAT OUT, TRY TO MAKE ONE FOR RECIPES TOO
        // ACCESS USER DATABASE AND CHECK IF LOGIN CREDENTIALS EQUALS DATABASE INFORMATION
        // FOR CREATING NEW USERS, ADD THEM INTO DATABASE
        // ADD SOME CODE TO CHECK USER INPUT (IE CORRECT DATA TYPE, INVALID CREDENTIALS)
        //------------------------------------------------------------------------------------------------

        // Receive intent
        //Intent i = new Intent();

        // Reuse bundle
        //Bundle b = i.getExtras();

        // Finds buttons
        Button myLoginButton = findViewById(R.id.loginbutton);
        Button ForgotPWButton = findViewById(R.id.forgotPW);
        Button SignUPButton = findViewById(R.id.signUP);

        // Create onClickListeners for buttons
        // Login
        myLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Creates EditText objects
                EditText etMyUserName = findViewById(R.id.signinUN);
                EditText etMyPassword = findViewById(R.id.signinPW);

                Bundle b = new Bundle();
                b.putString("Username", String.valueOf(etMyUserName));
                b.putString("Password", String.valueOf(etMyPassword));
                b.putString("class", "Login");
                Intent myIntent = new Intent(MainActivity.this, homePage.class);
                myIntent.putExtras(b);
                startActivity(myIntent);
            }
        });

        // Forgot Password
        ForgotPWButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(MainActivity.this, ForgotPassword_email.class);
                startActivity(myIntent);
            }
        });

        // Sign up
        SignUPButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(MainActivity.this, CreateNewUser.class);
                startActivity(myIntent);
            }
        });
    }
}