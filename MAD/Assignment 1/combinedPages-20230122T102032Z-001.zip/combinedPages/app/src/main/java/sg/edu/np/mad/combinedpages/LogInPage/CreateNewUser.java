package sg.edu.np.mad.combinedpages.LogInPage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import sg.edu.np.mad.combinedpages.R;
import sg.edu.np.mad.combinedpages.User;
import sg.edu.np.mad.combinedpages.homePage.homePage;

public class CreateNewUser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new_user);

        // -------------------------------------ASG 2-----------------------------------------------------
        // ADD NEW USERS INTO DATABASE
        // ADD SOME CODE TO CHECK USER INPUT (IE CORRECT DATA TYPE, INVALID CREDENTIALS)
        //------------------------------------------------------------------------------------------------

        // Receive intent
        Intent i = new Intent();

        // Reuse bundle
        Bundle b = i.getExtras();

        // Finds buttons
        Button mySignupButton = findViewById(R.id.signupbutton);

        // Create onClickListener for button
        mySignupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create EditText objects
                EditText etMyUserName = findViewById(R.id.signupUN);
                EditText etMyPassword = findViewById(R.id.signupPW);
                EditText etMyName = findViewById(R.id.signupname);
                EditText etMyDOB = findViewById(R.id.signupdob);
                EditText etMyEmail = findViewById(R.id.signupemail);

                // Create new User object
                User myUser = new User();
                myUser.setUsername(etMyUserName.getText().toString());
                myUser.setPassword(etMyPassword.getText().toString());
                myUser.setName(etMyName.getText().toString());
                myUser.setDateofbirth(etMyDOB.getText().toString());
                myUser.setEmail(etMyEmail.getText().toString());

                // Create Bundle to be sent to homePage
                b.putString("Username", myUser.getUsername());
                b.putString("Password", myUser.getPassword());
                b.putString("Name", myUser.getName());
                b.putString("DOB", myUser.getDateofbirth());
                b.putString("Email", myUser.getEmail());
                Intent myIntent = new Intent(CreateNewUser.this, MainActivity.class);
                myIntent.putExtras(b);
                startActivity(myIntent);
            }
        });
    }
}
