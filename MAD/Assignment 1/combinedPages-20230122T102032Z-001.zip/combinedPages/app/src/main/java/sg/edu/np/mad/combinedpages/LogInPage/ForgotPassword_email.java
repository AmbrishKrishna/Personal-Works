package sg.edu.np.mad.combinedpages.LogInPage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import sg.edu.np.mad.combinedpages.R;

public class ForgotPassword_email extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password_email);

        // CHECK EMAIL WITH DATABASE
        // ADD SOME CODE TO CHECK USER INPUT (IE CORRECT DATA TYPE, INVALID CREDENTIALS)

        // Receives any intents
        Intent intent = getIntent();

        // Find EditText
        EditText checkEmail = findViewById(R.id.checkEmail);

        // Create email
        String email = String.valueOf(checkEmail);

        // Finds buttons
        Button NextButton = findViewById(R.id.nextbutton);

        // Creates onClickListeners
        NextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(ForgotPassword_email.this, ForgotPassword_otp.class);
                startActivity(myIntent);
            }
        });
    }
}