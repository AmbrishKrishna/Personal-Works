package sg.edu.np.mad.combinedpages.searchPage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.widget.SearchView;

import java.util.ArrayList;
import java.util.List;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import sg.edu.np.mad.combinedpages.R;

public class searchPage extends AppCompatActivity {

    ListView listView;
    ArrayList<String> list;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_page);

        // -------------------------------------ASG 2-----------------------------------------------------
        // ACCESS DATABASE FOR RECIPES THEN MAKE A LIST
        // CLICKING ON A RESULT WILL DIRECT YOU TO THE RECIPE PAGE (IE SHOW YOU THE INFORMATION) (NOT SURE IF POSSIBLE)
        //------------------------------------------------------------------------------------------------

        // Receive intent
        Intent intent = getIntent();

        listView = findViewById(R.id.listView);
        list = new ArrayList<>();
        PopulateList(list);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);
    }

    public void PopulateList(List<String> list) {
        list.add("Bee Hoon");
        list.add("Chicken Rice");
        list.add("Fried Chicken");
        list.add("Laksa");
        list.add("Nasi Lemak");
        list.add("Fried Rice");
        list.add("Cupcakes");
        list.add("Chocolate Cakes");
        list.add("French Fries");
        list.add("Kampong Chicken");
        list.add("Ba Chor Mee");
        list.add("Prata");
        list.add("Tomato Sauced Prawn");
        list.add("Protein Booster Shake");
        list.add("Egg Cheese Sandwich");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);

        MenuItem search = menu.findItem(R.id.search_bar);
        SearchView searchView = (SearchView) search.getActionView();

        // attach setOnQueryTextListener
        // to search view defined above
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            // Override onQueryTextSubmit method
            // which is call
            // when submitquery is searched

            @Override
            public boolean onQueryTextSubmit(String query)
            {
                // If the list contains the search query
                // than filter the adapter
                // using the filter method
                // with the query as its argument
                if (list.contains(query)) { adapter.getFilter().filter(query); }
                else {
                    // Search query not found in List View
                    Toast.makeText(searchPage.this, "Not found", Toast.LENGTH_LONG).show();
                }
                return false;
            }

            // This method is overridden to filter
            // the adapter according to a search query
            // when the user is typing search
            @Override
            public boolean onQueryTextChange(String newText)
            {
                adapter.getFilter().filter(newText);
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }
}